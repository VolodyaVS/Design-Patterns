
class Account {
    var accountName: String
    var balance: Int
    
    init(accountName: String, balance: Int) {
        self.accountName = accountName
        self.balance = balance
    }
}

protocol Command {
    var isComplete: Bool { get set}
    func execute()
}

class Deposit: Command {
    var isComplete = false
    
    private var _account: Account
    private var _amount: Int
    
    init(account: Account, amount: Int) {
        self._account = account
        self._amount = amount
    }
    
    func execute() {
        _account.balance += _amount
        isComplete = true
    }
}

class Withdraw: Command {
    var isComplete = false
    
    private var _account: Account
    private var _amount: Int
    
    init(account: Account, amount: Int) {
        self._account = account
        self._amount = amount
    }
    
    func execute() {
        if _account.balance >= _amount {
            _account.balance -= _amount
            isComplete = true
        } else {
            print("Not enough money")
        }
    }
}

class TransactionManager {
    static let shared = TransactionManager()
    
    private var _transactions: [Command] = []
    var pendingTransactions: [Command] {
        get {
            return self._transactions.filter { $0.isComplete == false }
        }
    }
    
    private init() {}
    
    func addTransaction(command: Command) {
        self._transactions.append(command)
    }
    
    func processingTransactions() {
        _transactions.filter{ $0.isComplete == false }.forEach{ $0.execute() }
    }
}

let account = Account(accountName: "Volodya", balance: 1000)
let transactionManager = TransactionManager.shared

transactionManager.addTransaction(command: Deposit(account: account, amount: 100))
transactionManager.addTransaction(command: Withdraw(account: account, amount: 500))

transactionManager.pendingTransactions

account.balance

transactionManager.processingTransactions()
account.balance
