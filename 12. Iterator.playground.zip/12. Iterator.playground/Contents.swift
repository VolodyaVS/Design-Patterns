// part 1
//let array = [1, 2, 3, 4, 5]
//var iterator = array.makeIterator()
//
//while let item = iterator.next() {
//    print(item)
//}

//for item in array {
//    print(item)
//}

// part 2
class Driver {
    let isGoodDriver: Bool
    let name: String
    
    init(isGood: Bool, name: String) {
        self.isGoodDriver = isGood
        self.name = name
    }
}

class Car {
    
    private let drivers = [Driver(isGood: true, name: "Mark"),
                           Driver(isGood: false, name: "Ivan"),
                           Driver(isGood: true, name: "Marya"),
                           Driver(isGood: false, name: "Morgan")]
    
    var goodDriverIterator: GoodDriverIterator {
        GoodDriverIterator(drivers: drivers)
    }
    
}

extension Car: Sequence {
    func makeIterator() -> GoodDriverIterator {
        return GoodDriverIterator(drivers: drivers)
    }
}

protocol BasicIterator: IteratorProtocol {
    init(drivers: [Driver])
    
    func allDrivers() -> [Driver]
}

class GoodDriverIterator: BasicIterator {
    
    private var drivers = [Driver]()
    private var current = 0
    
    required init(drivers: [Driver]) {
        self.drivers = drivers.filter { $0.isGoodDriver }
    }
    
    func next() -> Driver? {
        defer { current += 1 }
        return drivers.count > current ? drivers[current] : nil
    }
    
    func allDrivers() -> [Driver] {
        drivers
    }
    
}

let car = Car()
let goodDriverIterator = car.goodDriverIterator.next()

let goodDriverIteratorViaSequence = car.makeIterator().allDrivers()

for driver in car {
    print(driver.name)
}
