
protocol Coworker {
    var level: Int { get }
    func hire(coworker: Coworker)
    func getInfo()
}

// branch
class Manager: Coworker {
    
    private var coworkers: [Coworker] = []
    
    var level: Int
    
    init(level: Int) {
        self.level = level
    }
    
    func hire(coworker: Coworker) {
        self.coworkers.append(coworker)
    }
    
    func getInfo() {
        print(self.level.description + "level manager")
        for coworker in coworkers {
            coworker.getInfo()
        }
    }
    
}

// leaf
class LowLevelManager: Coworker {
    
    var level: Int
    
    init(level: Int) {
        self.level = level
    }
    
    func hire(coworker: Coworker) {
        print("can't hire")
    }
    
    func getInfo() {
        print(self.level.description + "level manager")
    }
    
}

let topManager = Manager(level: 1)
let middelmanager = Manager(level: 2)

let juniorManagerOne = Manager(level: 3)
let juniorManagerTwo = Manager(level: 3)

let lowManager = Manager(level: 10)

topManager.hire(coworker: middelmanager)

middelmanager.hire(coworker: juniorManagerOne)
middelmanager.hire(coworker: juniorManagerTwo)

juniorManagerOne.hire(coworker: lowManager)

topManager.getInfo()
