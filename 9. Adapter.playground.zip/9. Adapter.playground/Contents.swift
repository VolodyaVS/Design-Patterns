
// adaptee
class SimpleCar {
    func sound() -> String {
        "tr-tr-tr-tr"
    }
}

// target
protocol SupercarProtocol {
    func makeNoise() -> String
}

class SuperCar: SupercarProtocol {
    func makeNoise() -> String {
        "wroom-wroom"
    }
}

// adapter
class SupercarAdapter: SupercarProtocol {
    var simpleCar: SimpleCar
    
    init(simpleCar: SimpleCar) {
        self.simpleCar = simpleCar
    }
    
    func makeNoise() -> String {
        simpleCar.sound()
    }
}
