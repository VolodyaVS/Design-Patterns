//part 1

//class DriveVehicle {
//
//    final func startVehicle() {
//        haveASeat()
////        closeTheDoor()
//        useProtection()
//        lookAtTheMirror()
//        turnSignal()
//        driveForward()
//    }
//
//    func haveASeat() {
//        preconditionFailure("this method should be overriden")
//    }
//
////    func closeTheDoor() {
////        print("if we have a door so close it")
////    }
//
//    func useProtection() {
//        preconditionFailure("this method should be overriden")
//    }
//
//    func lookAtTheMirror() {
//        preconditionFailure("this method should be overriden")
//    }
//
//    func turnSignal() {
//        preconditionFailure("this method should be overriden")
//    }
//
//    func driveForward() {
//        preconditionFailure("this method should be overriden")
//    }
//
//}
//
//class Bicycle: DriveVehicle {
//
//    override func haveASeat() {
//        print("sit down on a bicycle seat")
//    }
//
//    override func useProtection() {
//        print("wear a helmet")
//    }
//
//    override func lookAtTheMirror() {
//        print("look at the little mirror")
//    }
//
//    override func turnSignal() {
//        print("show left hand")
//    }
//
//    override func driveForward() {
//        print("pedal")
//    }
//
//}
//
//class Car: DriveVehicle {
//
//    override func haveASeat() {
//        print("sit down on a car seat")
//        closeTheDoor()
//    }
//
//    func closeTheDoor() {
//        print("close the door")
//    }
//
//    override func useProtection() {
//        print("fasten seat belt")
//    }
//
//    override func lookAtTheMirror() {
//        print("look at the rearview mirror")
//    }
//
//    override func turnSignal() {
//        print("turn on left turn light")
//    }
//
//    override func driveForward() {
//        print("push pedal")
//    }
//
//}
//
//let car = Car()
//let bicycle = Bicycle()
//
//car.startVehicle()
//print("###")
//bicycle.startVehicle()

//part 2
protocol DriveVehicleProtocol {
    func startVehicle()
    func haveASeat()
    func closeTheDoor()
    func useProtection()
    func lookAtTheMirror()
    func turnSignal()
    func driveForward()
}

extension DriveVehicleProtocol {
    
    func startVehicle() {
        haveASeat()
        useProtection()
        lookAtTheMirror()
        turnSignal()
        driveForward()
    }
    
    func haveASeat() {
        preconditionFailure("this method should be overriden")
    }
    
    func closeTheDoor() {
       
    }
    
    func useProtection() {
        preconditionFailure("this method should be overriden")
    }
    
    func lookAtTheMirror() {
        preconditionFailure("this method should be overriden")
    }
    
    func turnSignal() {
        preconditionFailure("this method should be overriden")
    }
    
    func driveForward() {
        preconditionFailure("this method should be overriden")
    }

}

class Bicycle: DriveVehicleProtocol {

    func haveASeat() {
        print("sit down on a bicycle seat")
    }
    
    func useProtection() {
        print("wear a helmet")
    }
    
    func lookAtTheMirror() {
        print("look at the little mirror")
    }
    
    func turnSignal() {
        print("show left hand")
    }
    
    func driveForward() {
        print("pedal")
    }
    
}

class Car: DriveVehicleProtocol {

    func haveASeat() {
        print("sit down on a car seat")
        closeTheDoor()
    }
    
    func closeTheDoor() {
        print("close the door")
    }
    
    func useProtection() {
        print("fasten seat belt")
    }
    
    func lookAtTheMirror() {
        print("look at the rearview mirror")
    }
    
    func turnSignal() {
        print("turn on left turn light")
    }
    
    func driveForward() {
        print("push pedal")
    }
    
}

let car = Car()
let bicycle = Bicycle()

car.startVehicle()
print("###")
bicycle.startVehicle()
